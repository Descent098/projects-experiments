The purpose of these specific files is a portable windows version of python for use with the spark library on 64-bit windows. 

If you want a broad explanation of using embedded python, take a look at this gist:
https://gist.github.com/Descent098/045e3e42f5ba39bf216cfb3255680d9d